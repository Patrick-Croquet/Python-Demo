# Déclaration du tableau Nb
Nb = [0] * 6

# Remplissage du tableau avec les carrés des indices
# Affichage des éléments du tableau
for i in range(6):
    Nb[i] = i * i
    print(Nb[i])    