note = [0] * 7
 
print(note)
