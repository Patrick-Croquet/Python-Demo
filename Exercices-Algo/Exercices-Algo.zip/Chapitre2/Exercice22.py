# VARIABLES
nb = None  # Déclaration de la variable 'nb' (sans initialisation)
carre = None  # Déclaration de la variable 'carre' (sans initialisation)

# Demander un nombre à l'utilisateur
nb = float(input("Entrez un nombre : "))  # Lit un nombre à partir du clavier et le stocke dans 'nb'

# Calculer le carré du nombre
carre = nb * nb

# Afficher le résultat
print("Son carré est : ", carre)  # Affiche le message "Son carré est : " suivi de la valeur de 'carre'