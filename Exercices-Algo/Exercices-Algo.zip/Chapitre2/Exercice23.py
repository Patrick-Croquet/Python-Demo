# VARIABLES
prenom = None  # Déclaration de la variable 'prenom' (sans initialisation)

# Demander le prénom à l'utilisateur
prenom = input("Quel est votre prénom ? ")  # Lit un chaîne de caractères à partir du clavier et la stocke dans 'prenom'

# Afficher un message personnalisé
print("Bonjour ", prenom, "!")  # Affiche le message "Bonjour " suivi de la valeur de 'prenom' et du point d'exclamationP