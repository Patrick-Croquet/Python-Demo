# VARIABLES
val = 231  # Déclaration et initialisation de la variable 'val' avec la valeur 231
double = 0  # Déclaration et initialisation de la variable 'double' (ici, on initialise à 0)

# Opérations
double = val * 2  # Calcul de la valeur de 'double'

# AFFICHER (fonction intégrée à Python)
print(val)  # Affiche la valeur de 'val'
print(double)  # Affiche la valeur de 'double'