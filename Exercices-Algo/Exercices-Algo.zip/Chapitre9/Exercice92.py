# Variable Mot en Caractère
# Variable Nb en Entier

# Debut
Mot = input("Entrez un mot : ")  # Lire Mot
Nb = len(Mot)  # Nb ← Len(Mot)
print("Ce mot compte", Nb, "lettres")  # Ecrire "Ce mot compte ", Nb, " lettres"
# Fin
