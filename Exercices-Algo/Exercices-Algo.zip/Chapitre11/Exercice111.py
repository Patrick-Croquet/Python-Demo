def Sum(a, b, c, d, e):
    return a + b + c + d + e

print(Sum(1,2,3,4,5)) # résultat 15